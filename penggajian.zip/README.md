# Aplikasi Penggajian Pegawai Menggunakan Framework Codeigniter
CodeIgniter v3.1.13 (Current version)
