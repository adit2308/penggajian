                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <div class="card mx-auto" style="width: 35%;">
                        <div class="card-header bg-primary text-white">
                            Laporan Data Jabatan
                        </div>
                        <form method="POST" action="<?php echo base_url('admin/laporanJabatan/cetakDataJabatan') ?>">
                            <div class="card-body">


                                <button style="width: 100%;" type="submit" class="btn btn-success"><i class="fas fa-print"> Cetak Data Jabatan</i></button>
                        </form>
                    </div>
                </div>

                </div>
                <!-- /.container-fluid -->

                </div>
                <!-- End of Main Content -->